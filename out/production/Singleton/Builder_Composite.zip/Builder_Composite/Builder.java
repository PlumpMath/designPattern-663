package Builder_Composite;

/**
 * Created by jht on 2016/11/2.
 */
public interface Builder {
    public void MakeBTree(int number);
    public void Display();
}
